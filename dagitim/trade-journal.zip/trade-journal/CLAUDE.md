# Trade Journal — kişisel trade günlüğü

Bu dosya projenin kalıcı talimatıdır. Yeni bir Claude Code konuşmasının başında oku.

## Proje nedir
Bilal'in kişisel trade günlüğü: her trade için giriş / TP1 / TP2 / stop, R/R, gerekçe, giriş koşulu, kaynak, güven, grafikler (görseller), durum (Bekliyor, Açık, TP1, TP2, Stop, İptal, Elle kapandı), çıkış fiyatı, gerçekleşen R, zaman çizelgesi notları, istatistikler, filtre/arama, CSV/JSON dışa aktarma ve **görseller dahil tam yedek / yedek yükleme**. Kaynak: `konsensus` projesindeki `/trade-defteri` sayfasından ayrıştırıldı; iki proje artık **bağımsız**.

## Nasıl çalışıyoruz (Bilal)
- Bilal kodlama bilmiyor ama teknik kavramları hızlı kavrıyor. Türkçe, kısa ve net anlat.
- Her adımda: ne yaptığını 2-3 cümleyle özetle; Bilal'in yapması gereken bir şey varsa numaralı adımlarla yaz.
- Onay sormadan ilerle (Bilal'in tercihi); kural netleşmezse makul varsayım yap, `DURUM.md`'ye "Bilal'le teyit edilecek" diye yaz.
- Gizli bilgileri (token, şifre) asla koda yazma; Cloudflare secret olarak girilir.
- Her iş sonunda `DURUM.md`'yi güncelle. Yerelde denemeden ("çalışıyor" demeden) bitirme; mümkünse Playwright ile uçtan uca dene.

## Teknik altyapı
- **Astro 7** (`output: 'static'`, sayfa/API rotalarında `export const prerender = false`) + **@astrojs/cloudflare** adaptörü, **Cloudflare Workers** üzerinde, veri **Cloudflare D1**.
- D1 binding adı `DB`, `src/lib/db.ts` içindeki `getDb()` ile alınır (`import { env } from 'cloudflare:workers'`).
- Dağıtım: `npm run deploy` (`astro build && wrangler deploy -c dist/server/wrangler.json`). Git push ile Cloudflare Workers Builds otomatik yayınlar (kurulum README'de).
- Yerel geliştirme: `npm install`, `npm run dev` (yerel D1 kendiliğinden oluşur, tablolar API'nin ilk isteğinde açılır).

## Dosyalar
- `src/pages/index.astro` — tüm arayüz (HTML + `<script is:inline>` + global stil). Tek dosya, framework yok; istemci JS düz (`var`, `function`).
- `src/pages/api/trade.ts` — REST: `GET` (liste ya da `?gorsel=ID` ile görsel), `POST` (trade upsert ya da `?gorsel=1` ile görsel yükle), `DELETE ?id=`. Tabloları `CREATE TABLE IF NOT EXISTS` ile kendisi kurar.
- `src/layouts/Layout.astro`, `src/styles/tasarim.css` — çerçeve ve renk/yazı değişkenleri.
- `migrations/0001_trade_journal.sql` — şema kaydı.

## Veri modeli
`trade_kayitlari(id, tarih, doc JSON, guncelleme)`; `doc` şu şekildedir:
```
{ id, date: 'YYYY-AA-GG', tk: 'EKGYO', side: 'L'|'S', en, tp1, tp2, sl (metin, Türkçe ondalıklı olabilir "12,50"),
  why, cond, conf: 'Düşük'|'Orta'|'Yüksek', src: ['V10 bülten'|'Kendi fikrim'], status, exit,
  images: [{ id, cap }], updates: [{ uid, ts, stage, text, price, images: [{ id, cap }], auto }] }
```
Görseller `trade_gorseller(id, veri)` tablosunda küçültülmüş JPEG data URL olarak durur (istemcide 1400 px, kalite 0,72). Trade JSON'u yalnızca görsel id'sini taşır.
- Gerçekleşen R: `realR(t)` (durum TP1/TP2/Stop ise ilgili seviyeyi, yoksa çıkış fiyatını kullanır).

## Tasarım ("gazete + terminal")
Zemin `#F4F2EC`, kart `#FFFFFF`, kenarlık `#E2DED3`, metin `#15171C`, koyu `#11151F`, marka `#3438C9`, kehribar `#E9A23B`, yükseliş `#0F7A4B`, düşüş `#B83227` (yön yanında ▲/▼ işareti). Başlıklar Fraunces, gövde IBM Plex Sans, rakam/kod IBM Plex Mono. Butonlar en az 44 px, kart köşeleri 14-16 px, mobil öncelikli.

## Bilinen eksikler / güvenlik
- **Sayfa ve API herkese açık, kimlik doğrulama yok.** Adresi bilen görür/siler. Yaygın kullanımdan önce Cloudflare Access (e-posta girişi) ya da basit şifre eklenmeli. Bilal bunu şimdilik istemedi; adresi paylaşma.
- Toplu yedek: düzenli otomatik yedek yok, "Tam yedek" düğmesiyle elle alınır.

## Fikir listesi (sırasız)
İstatistik sayfası (aylık R eğrisi, isabet oranı, hisse/kaynak bazında performans, en büyük kayıplar), etiketler ve kaynak bazlı filtre, giriş anında "bu trade kuralına uygun mu?" kontrol listesi, trade başına işlem maliyeti/komisyon, hedef/stop yaklaşınca uyarı, fiyat entegrasyonu (Yahoo, sunucu tarafında; konsensus'taki `/api/fiyat` örnek), Cloudflare Access ile giriş, tam yedeğin zamanlanması, yazdırma/PDF haftalık özet.
