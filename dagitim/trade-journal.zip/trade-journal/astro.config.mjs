// @ts-check
import { defineConfig } from 'astro/config';
import cloudflare from '@astrojs/cloudflare';

// Sayfa ve API rotaları (`export const prerender = false`) Cloudflare Workers'ta çalışır, veriler D1'de durur.
export default defineConfig({
	output: 'static',
	adapter: cloudflare({
		platformProxy: { enabled: true },
	}),
});
