-- Trade Journal: trade kayıtları (JSON doküman) ve görseller (küçültülmüş JPEG data URL).
-- API ilk istekte tabloları kendisi de oluşturur (src/pages/api/trade.ts); bu dosya kayıt ve `wrangler d1 migrations` içindir.
CREATE TABLE IF NOT EXISTS trade_kayitlari (
	id TEXT PRIMARY KEY,
	tarih TEXT NOT NULL,
	doc TEXT NOT NULL,
	guncelleme TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS trade_gorseller (
	id TEXT PRIMARY KEY,
	veri TEXT NOT NULL,
	olusturulma TEXT NOT NULL DEFAULT (datetime('now'))
);
