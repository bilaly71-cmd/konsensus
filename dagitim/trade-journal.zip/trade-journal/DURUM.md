# DURUM

- (01.10.2026) Proje `konsensus` sitesindeki `/trade-defteri` sayfasından ayrıştırıldı: arayüz (`src/pages/index.astro`), API (`src/pages/api/trade.ts`), D1 şeması, tasarım değişkenleri. Ek olarak **tam yedek (görseller dahil)** ve **yedek yükle** eklendi (konsensus'taki sayfaya da eklendi).
- Yerelde denendi: trade ekleme, durum değiştirme, not/grafik, silme, tam yedek indirme → silme → yedek yükleme (görseller geri geliyor).
- Henüz canlıya alınmadı; Bilal'in yapacakları README.md'de.
- Bilal'le teyit edilecek: proje adı / alan adı, kimlik doğrulama (Cloudflare Access ya da şifre) istenip istenmediği.
