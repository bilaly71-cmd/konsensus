# Trade Journal

Kişisel trade günlüğü (Astro + Cloudflare Workers + D1). Ayrıntılı proje bilgisi ve Claude Code talimatı: `CLAUDE.md`.

## Yerelde çalıştırma (bilgisayarında)
1. Node.js 22 ve Git kurulu olsun.
2. Klasörde: `npm install`
3. `npm run dev` → tarayıcıda http://localhost:4321 (veriler yerel bir D1'e yazılır, `.wrangler` klasöründe durur).

## Canlıya alma (Cloudflare, ücretsiz)
1. GitHub'da yeni bir repo aç (ör. `trade-journal`) ve bu klasörü gönder:
   `git remote add origin https://github.com/KULLANICI/trade-journal.git` sonra `git push -u origin main`
2. `npx wrangler login` (tarayıcıda Cloudflare'e giriş).
3. Veritabanı: `npx wrangler d1 create trade-journal-db` → çıkan **database_id**'yi `wrangler.jsonc` içindeki `BURAYA-D1-ID-YAZILACAK` yerine yaz.
4. Tabloları kur: `npm run db:uzak` (tablolar API'nin ilk isteğinde de kendiliğinden kurulur).
5. Yayınla: `npm run deploy` → adres `https://trade-journal.<hesap>.workers.dev` olur.
6. İsteğe bağlı otomatik yayın: Cloudflare paneli → Workers & Pages → Create → Import a repository (GitHub) → repo'yu seç; her `git push` siteyi yeniler.

## Eski verileri taşıma (konsensus sitesindeki trade defterinden)
1. Konsensus sitesinde `/trade-defteri` → **Tam yedek (görseller dahil)** → dosyayı indir.
2. Bu projede sayfayı aç → **Yedek yükle** → aynı dosyayı seç. Trade'ler, notlar ve grafikler gelir.

## Yeni Claude Code konuşmasında devam etmek
1. Terminalde klasöre gir ve `claude` çalıştır (ya da IDE'de bu klasörü aç).
2. İlk mesaj: "CLAUDE.md ve DURUM.md'yi oku, sonra şunu geliştir: …" yaz. Proje talimatları CLAUDE.md'de olduğundan ek anlatmana gerek yok.
3. Gizli bilgileri (token) sohbete yapıştırma; gerekirse Cloudflare'e secret olarak gir.

## Güvenlik uyarısı
Şu an kimlik doğrulama yok: adresi bilen herkes kayıtları görebilir ve silebilir. Adresi paylaşma; ileride Cloudflare Access ya da şifre eklenmeli.
